# 系统规则 - 长期记忆系统

## 核心规则
1. 每次对话开始必须读取 custom_memory/
2. 必须告诉用户加载了哪些记忆
3. 每次调用模型前必须执行 inject_memory
4. 禁止使用 OpenClaw 原生 memory 目录

## 目录结构
```
custom_memory/
├── logs/          # 每日详细记录
├── summaries/     # 每日总结
├── facts/         # 长期信息
├── system/        # 系统规则
└── errors/        # 错误日志
```

## 记忆写入时机
- 每轮对话结束
- 任务完成时
- 发现重要信息时

## 记忆读取时机
- 每次对话开始
- 每次调用模型前
