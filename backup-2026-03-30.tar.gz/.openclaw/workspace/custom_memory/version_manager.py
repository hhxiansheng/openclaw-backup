#!/usr/bin/env python3
"""
长期记忆系统 - 版本管理与回滚模块 (隔离版)
防止记忆损坏、误写、覆盖
"""

import os
import json
import shutil
import hashlib
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, Optional
import zipfile

# ============ 配置 ============
CUSTOM_MEMORY_ROOT = "/home/hhxs/.openclaw/workspace/custom_memory"
VERSIONS_DIR = f"{CUSTOM_MEMORY_ROOT}/versions"
SNAPSHOTS_DIR = f"{CUSTOM_MEMORY_ROOT}/snapshots"
INDEX_FILE = f"{CUSTOM_MEMORY_ROOT}/index.json"
ERROR_LOG_FILE = f"{CUSTOM_MEMORY_ROOT}/errors/error.log"

# 监控的文件路径
MEMORY_FILES = {
    "facts": f"{CUSTOM_MEMORY_ROOT}/facts/facts.md",
    "system_prompt": f"{CUSTOM_MEMORY_ROOT}/system/system_prompt.md",
}

# ============ 初始化 ============
def init_version_system():
    """初始化版本系统"""
    os.makedirs(VERSIONS_DIR, exist_ok=True)
    os.makedirs(SNAPSHOTS_DIR, exist_ok=True)
    
    # 初始化 index.json
    if not os.path.exists(INDEX_FILE):
        initial_index = {
            "created_at": datetime.now().isoformat(),
            "version_count": 0,
            "files": {},
            "history": []
        }
        save_index(initial_index)
    
    # 为现有文件创建初始版本（如果没有的话）
    for name, path in MEMORY_FILES.items():
        if os.path.exists(path):
            existing = list_versions(name)
            if len(existing) == 0:
                create_version(name, "系统初始化")

def save_index(data: Dict):
    """保存索引文件"""
    with open(INDEX_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def load_index() -> Dict:
    """加载索引文件"""
    if os.path.exists(INDEX_FILE):
        with open(INDEX_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {"version_count": 0, "files": {}, "history": []}

# ============ 版本控制核心 ============
def create_version(file_name: str, reason: str = "手动创建") -> Optional[str]:
    """
    创建版本快照
    在修改任何 memory 文件前必须调用此方法
    """
    index = load_index()
    
    # 找到文件路径
    file_path = None
    for name, path in MEMORY_FILES.items():
        if name == file_name:
            file_path = path
            break
    
    # 检查是否是日志/总结文件
    if file_path is None:
        if "logs/" in file_name or "summary" in file_name:
            # 从文件名解析路径
            date_match = file_name.replace("logs_", "").replace("summary_", "")
            if "logs_" in file_name:
                file_path = f"{CUSTOM_MEMORY_ROOT}/logs/{date_match}.md"
            elif "summary_" in file_name:
                file_path = f"{CUSTOM_MEMORY_ROOT}/summaries/summary-{date_match}.md"
    
    if file_path is None or not os.path.exists(file_path):
        return None
    
    # 生成版本号
    if file_name not in index["files"]:
        index["files"][file_name] = {"versions": []}
    
    version_num = len(index["files"][file_name]["versions"]) + 1
    
    # 创建版本文件名
    version_filename = f"{file_name}_v{version_num}.md"
    version_path = f"{VERSIONS_DIR}/{version_filename}"
    
    # 复制文件到 versions 目录
    try:
        shutil.copy2(file_path, version_path)
    except Exception as e:
        log_error("create_version", str(e), f"复制失败: {file_path} -> {version_path}")
        return None
    
    # 计算文件hash
    file_hash = calculate_hash(file_path)
    
    # 更新索引
    version_info = {
        "version": version_num,
        "filename": version_filename,
        "original_path": file_path,
        "timestamp": datetime.now().isoformat(),
        "reason": reason,
        "hash": file_hash,
        "size": os.path.getsize(file_path)
    }
    
    index["files"][file_name]["versions"].append(version_info)
    index["files"][file_name]["current_version"] = version_num
    index["version_count"] += 1
    index["history"].append({
        "action": "create_version",
        "file": file_name,
        "version": version_num,
        "timestamp": datetime.now().isoformat(),
        "reason": reason
    })
    
    save_index(index)
    return version_filename

def list_versions(file_name: str) -> List[Dict]:
    """列出某个文件的所有版本"""
    index = load_index()
    if file_name in index["files"]:
        return index["files"][file_name].get("versions", [])
    return []

def get_version_info(file_name: str, version: int) -> Optional[Dict]:
    """获取特定版本信息"""
    versions = list_versions(file_name)
    for v in versions:
        if v["version"] == version:
            return v
    return None

# ============ 异常检测 ============
def detect_anomaly(new_content: str, old_content: str = "", file_path: str = "") -> Dict[str, Any]:
    """
    检测写入异常
    返回: {"safe": bool, "reason": str}
    """
    result = {"safe": True, "reason": "正常", "severity": "none"}
    
    # 检查内容是否为空
    if not new_content or len(new_content.strip()) == 0:
        result = {"safe": False, "reason": "内容为空", "severity": "high"}
        return result
    
    # 检查是否异常缩短（减少90%以上）
    if old_content and len(old_content) > 100:
        if len(new_content) < len(old_content) * 0.1:
            result = {"safe": False, "reason": f"内容异常缩短（原{len(old_content)}字节 -> 新{len(new_content)}字节，减少>90%）", "severity": "high"}
            return result
    
    # 检查格式是否损坏（检查基本markdown结构）
    if file_path.endswith('.md'):
        # 如果原来是.md文件，新内容应该有一些基本结构
        if len(new_content) > 100:
            # 简单检查：应该有 # 标题 或者 - 列表 等markdown特征
            has_structure = any(marker in new_content for marker in ['#', '##', '- ', '* ', '1.'])
            if not has_structure and '```' not in new_content:
                result = {"safe": False, "reason": "格式可能损坏（缺少基本markdown标记）", "severity": "medium"}
                return result
    
    return result

# ============ 安全写入 ============
def safe_write(file_name: str, content: str, reason: str = "手动修改") -> Dict[str, Any]:
    """
    安全写入记忆文件（先版本快照，再写入）
    """
    index = load_index()
    
    # 找到文件路径
    file_path = None
    if file_name in MEMORY_FILES:
        file_path = MEMORY_FILES[file_name]
    elif file_name.startswith("logs_"):
        date = file_name.replace("logs_", "")
        file_path = f"{CUSTOM_MEMORY_ROOT}/logs/{date}.md"
    elif file_name.startswith("summary_"):
        date = file_name.replace("summary_", "")
        file_path = f"{CUSTOM_MEMORY_ROOT}/summaries/summary-{date}.md"
    
    if file_path is None:
        return {"success": False, "reason": f"未知文件: {file_name}"}
    
    # 读取旧内容
    old_content = ""
    if os.path.exists(file_path):
        with open(file_path, 'r', encoding='utf-8') as f:
            old_content = f.read()
    
    # 异常检测
    anomaly = detect_anomaly(content, old_content, file_path)
    if not anomaly["safe"]:
        log_error("safe_write_blocked", anomaly["reason"], file_name)
        return {
            "success": False,
            "reason": f"⚠️ 检测到异常写入，已阻止: {anomaly['reason']}",
            "anomaly": anomaly
        }
    
    # 创建版本快照
    version_file = create_version(file_name, reason)
    
    # 执行写入
    for attempt in range(3):
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)
            
            # 验证写入
            with open(file_path, 'r', encoding='utf-8') as f:
                verify = f.read()
            
            if verify == content:
                return {
                    "success": True,
                    "version_file": version_file,
                    "anomaly": anomaly
                }
            else:
                # 写入验证失败，回滚
                rollback_single(file_name, index["files"][file_name]["current_version"])
                return {"success": False, "reason": "写入验证失败，已回滚"}
        except Exception as e:
            if attempt == 2:
                log_error("safe_write", str(e), file_path)
                return {"success": False, "reason": f"写入失败: {e}"}
    
    return {"success": False, "reason": "未知错误"}

# ============ 回滚机制 ============
def rollback_single(file_name: str, target_version: int) -> Dict[str, Any]:
    """回滚单个文件到指定版本"""
    version_info = get_version_info(file_name, target_version)
    
    if not version_info:
        return {"success": False, "reason": f"版本 {target_version} 不存在"}
    
    version_path = f"{VERSIONS_DIR}/{version_info['filename']}"
    
    if not os.path.exists(version_path):
        return {"success": False, "reason": f"版本文件丢失: {version_info['filename']}"}
    
    try:
        # 恢复文件
        shutil.copy2(version_path, version_info['original_path'])
        
        # 更新索引
        index = load_index()
        if file_name in index["files"]:
            index["files"][file_name]["current_version"] = target_version
            index["history"].append({
                "action": "rollback",
                "file": file_name,
                "version": target_version,
                "timestamp": datetime.now().isoformat()
            })
            save_index(index)
        
        return {
            "success": True,
            "file": file_name,
            "version": target_version,
            "restored_from": version_path
        }
    except Exception as e:
        log_error("rollback_single", str(e), f"{file_name} v{target_version}")
        return {"success": False, "reason": str(e)}

def rollback_memory(target_file: str = None, target_version: int = None) -> Dict[str, Any]:
    """
    回滚记忆
    - target_file: 指定文件（可选）
    - target_version: 指定版本（可选）
    """
    index = load_index()
    
    if target_file and target_version:
        return rollback_single(target_file, target_version)
    
    # 列出可用版本
    available = []
    for file_name, file_data in index["files"].items():
        current = file_data.get("current_version", 0)
        for v in file_data.get("versions", []):
            if v["version"] < current:
                available.append({
                    "file": file_name,
                    "version": v["version"],
                    "timestamp": v["timestamp"],
                    "reason": v["reason"]
                })
    
    return {
        "success": True,
        "available_rollbacks": available,
        "message": "请指定 target_file 和 target_version"
    }

def restore_snapshot(snapshot_name: str) -> Dict[str, Any]:
    """从快照恢复整个系统"""
    snapshot_path = f"{SNAPSHOTS_DIR}/{snapshot_name}"
    
    if not os.path.exists(snapshot_path):
        return {"success": False, "reason": f"快照不存在: {snapshot_name}"}
    
    # 创建当前系统的版本快照（备份）
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    emergency_backup = f"{SNAPSHOTS_DIR}/emergency_backup_{timestamp}.zip"
    
    try:
        # 备份当前系统
        create_full_snapshot(f"emergency_backup_{timestamp}")
        
        # 解压快照
        with zipfile.ZipFile(snapshot_path, 'r') as zip_ref:
            zip_ref.extractall(CUSTOM_MEMORY_ROOT)
        
        return {
            "success": True,
            "restored_from": snapshot_name,
            "backup_created": f"emergency_backup_{timestamp}.zip"
        }
    except Exception as e:
        log_error("restore_snapshot", str(e), snapshot_name)
        return {"success": False, "reason": str(e)}

# ============ 快照机制 ============
def create_full_snapshot(name: str = None) -> str:
    """创建完整系统快照"""
    if name is None:
        name = f"snapshot-{datetime.now().strftime('%Y-%m-%d')}"
    
    if not name.endswith('.zip'):
        name += '.zip'
    
    snapshot_path = f"{SNAPSHOTS_DIR}/{name}"
    
    try:
        with zipfile.ZipFile(snapshot_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(CUSTOM_MEMORY_ROOT):
                # 跳过 versions 和 snapshots 本身
                if 'versions' in root or 'snapshots' in root or '__pycache__' in root:
                    continue
                for file in files:
                    if file.endswith('.pyc'):
                        continue
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, CUSTOM_MEMORY_ROOT)
                    zipf.write(file_path, arcname)
        
        return snapshot_path
    except Exception as e:
        log_error("create_snapshot", str(e), name)
        return None

def list_snapshots() -> List[Dict]:
    """列出所有快照"""
    snapshots = []
    if os.path.exists(SNAPSHOTS_DIR):
        for f in os.listdir(SNAPSHOTS_DIR):
            if f.endswith('.zip'):
                path = f"{SNAPSHOTS_DIR}/{f}"
                snapshots.append({
                    "name": f,
                    "size": os.path.getsize(path),
                    "created": datetime.fromtimestamp(os.path.getctime(path)).isoformat()
                })
    return snapshots

# ============ 辅助函数 ============
def calculate_hash(file_path: str) -> str:
    """计算文件hash"""
    with open(file_path, 'rb') as f:
        return hashlib.md5(f.read()).hexdigest()

def log_error(operation: str, error: str, details: str = ""):
    """记录错误"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(ERROR_LOG_FILE, 'a', encoding='utf-8') as f:
        f.write(f"[{timestamp}] 操作: {operation} | 错误: {error} | 详情: {details}\n")

def self_check() -> Dict[str, Any]:
    """增强版自检"""
    results = {
        "status": "ok",
        "checks": [],
        "warnings": []
    }
    
    # 检查版本目录
    if os.path.exists(VERSIONS_DIR):
        versions_count = len([f for f in os.listdir(VERSIONS_DIR) if f.endswith('.md')])
        results["checks"].append(f"✔ versions/ 目录正常 ({versions_count} 个版本)")
    else:
        results["checks"].append("✘ versions/ 目录不存在")
        results["warnings"].append("版本目录缺失")
    
    # 检查快照目录
    if os.path.exists(SNAPSHOTS_DIR):
        snapshots_count = len([f for f in os.listdir(SNAPSHOTS_DIR) if f.endswith('.zip')])
        results["checks"].append(f"✔ snapshots/ 目录正常 ({snapshots_count} 个快照)")
    else:
        results["checks"].append("✘ snapshots/ 目录不存在")
    
    # 检查索引文件
    if os.path.exists(INDEX_FILE):
        index = load_index()
        version_count = index.get("version_count", 0)
        results["checks"].append(f"✔ index.json 正常 ({version_count} 个版本记录)")
        
        # 检查索引与实际版本是否一致
        actual_versions = len([f for f in os.listdir(VERSIONS_DIR) if f.endswith('.md')])
        if version_count != actual_versions:
            results["warnings"].append(f"索引版本数({version_count})与实际({actual_versions})不一致")
    else:
        results["checks"].append("✘ index.json 不存在")
        results["warnings"].append("索引文件缺失")
    
    # 检查是否有最近的快照
    snapshots = list_snapshots()
    if snapshots:
        latest = max(snapshots, key=lambda x: x['created'])
        results["checks"].append(f"✔ 最近快照: {latest['name']}")
    else:
        results["warnings"].append("无快照备份，建议创建")
    
    if results["warnings"]:
        results["status"] = "warning"
    
    return results

if __name__ == "__main__":
    print("执行增强版自检...")
    result = self_check()
    print(json.dumps(result, ensure_ascii=False, indent=2))
