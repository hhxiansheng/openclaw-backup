#!/usr/bin/env python3
"""
长期记忆系统 - 核心管理器 (隔离版)
隔离 OpenClaw 原生 memory，完全独立实现
"""

import os
import json
import shutil
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, List, Dict, Any

# ============ 配置 ============
CUSTOM_MEMORY_ROOT = "/home/hhxs/.openclaw/workspace/custom_memory"
LOGS_DIR = f"{CUSTOM_MEMORY_ROOT}/logs"
SUMMARIES_DIR = f"{CUSTOM_MEMORY_ROOT}/summaries"
FACTS_FILE = f"{CUSTOM_MEMORY_ROOT}/facts/facts.md"
SYSTEM_PROMPT_FILE = f"{CUSTOM_MEMORY_ROOT}/system/system_prompt.md"
ERROR_LOG_FILE = f"{CUSTOM_MEMORY_ROOT}/errors/error.log"

# ============ 初始化检查 ============
def init_memory_system():
    """初始化记忆系统，确保目录结构存在"""
    dirs = [LOGS_DIR, SUMMARIES_DIR, f"{CUSTOM_MEMORY_ROOT}/facts", f"{CUSTOM_MEMORY_ROOT}/system", f"{CUSTOM_MEMORY_ROOT}/errors"]
    for d in dirs:
        os.makedirs(d, exist_ok=True)
    
    # 初始化 facts 文件
    if not os.path.exists(FACTS_FILE):
        with open(FACTS_FILE, 'w', encoding='utf-8') as f:
            f.write("# 长期事实库\n\n## 用户信息\n- 用户名：运维小飞棍\n- 地点：广州\n- 时区：Asia/Shanghai\n\n## 项目信息\n（待填充）\n\n## 偏好设置\n（待填充）\n\n")
    
    # 初始化 system prompt
    if not os.path.exists(SYSTEM_PROMPT_FILE):
        with open(SYSTEM_PROMPT_FILE, 'w', encoding='utf-8') as f:
            f.write("# 系统记忆注入Prompt\n\n这是你的长期记忆系统。每次对话前必须读取并注入以下信息。\n\n")
    
    return True

# ============ 错误处理 ============
def log_error(operation: str, error: str, details: str = ""):
    """记录错误到 error.log"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(ERROR_LOG_FILE, 'a', encoding='utf-8') as f:
        f.write(f"[{timestamp}] 操作: {operation} | 错误: {error} | 详情: {details}\n")

# ============ 写入记忆 ============
def write_log(message: str, metadata: Optional[Dict] = None):
    """写入每日日志"""
    today = datetime.now().strftime("%Y-%m-%d")
    log_file = f"{LOGS_DIR}/{today}.md"
    
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    content = f"## {timestamp}\n\n"
    content += f"**消息**: {message}\n"
    if metadata:
        content += f"**元数据**: {json.dumps(metadata, ensure_ascii=False)}\n"
    content += "\n---\n\n"
    
    for attempt in range(3):
        try:
            with open(log_file, 'a', encoding='utf-8') as f:
                f.write(content)
            return True
        except Exception as e:
            if attempt == 2:
                log_error("write_log", str(e), log_file)
            continue
    return False

def append_fact(category: str, fact: str):
    """追加长期事实"""
    for attempt in range(3):
        try:
            with open(FACTS_FILE, 'a', encoding='utf-8') as f:
                f.write(f"\n## {category}\n- {fact}\n")
            return True
        except Exception as e:
            if attempt == 2:
                log_error("append_fact", str(e), FACTS_FILE)
            continue
    return False

# ============ 读取记忆 ============
def read_recent_summaries(days: int = 3) -> str:
    """读取最近N天的总结"""
    summaries = []
    today = datetime.now()
    
    for i in range(days):
        date = (today - timedelta(days=i)).strftime("%Y-%m-%d")
        summary_file = f"{SUMMARIES_DIR}/summary-{date}.md"
        if os.path.exists(summary_file):
            try:
                with open(summary_file, 'r', encoding='utf-8') as f:
                    summaries.append(f.read())
            except Exception as e:
                log_error("read_summary", str(e), summary_file)
    
    return "\n\n".join(summaries) if summaries else "（无历史总结）"

def read_facts() -> str:
    """读取长期事实"""
    if os.path.exists(FACTS_FILE):
        try:
            with open(FACTS_FILE, 'r', encoding='utf-8') as f:
                return f.read()
        except Exception as e:
            log_error("read_facts", str(e), FACTS_FILE)
    return "（无长期事实）"

def read_system_prompt() -> str:
    """读取系统提示"""
    if os.path.exists(SYSTEM_PROMPT_FILE):
        try:
            with open(SYSTEM_PROMPT_FILE, 'r', encoding='utf-8') as f:
                return f.read()
        except Exception as e:
            log_error("read_system_prompt", str(e), SYSTEM_PROMPT_FILE)
    return ""

def read_logs(days: int = 3) -> str:
    """读取最近N天的日志"""
    logs = []
    today = datetime.now()
    
    for i in range(days):
        date = (today - timedelta(days=i)).strftime("%Y-%m-%d")
        log_file = f"{LOGS_DIR}/{date}.md"
        if os.path.exists(log_file):
            try:
                with open(log_file, 'r', encoding='utf-8') as f:
                    logs.append(f"=== {date} ===\n{f.read()}")
            except Exception as e:
                log_error("read_logs", str(e), log_file)
    
    return "\n".join(logs) if logs else "（无日志）"

# ============ 记忆注入 ============
def inject_memory() -> str:
    """
    核心功能：拼接所有记忆到统一上下文
    必须在调用模型前执行此函数
    """
    separator = "\n" + "="*50 + "\n"
    
    injected = f"{separator}【长期记忆系统 - 记忆注入】{separator}"
    injected += f"## 最近3天总结:\n{read_recent_summaries(3)}{separator}"
    injected += f"## 长期事实:\n{read_facts()}{separator}"
    injected += f"## 系统规则:\n{read_system_prompt()}{separator}"
    injected += "="*50 + "\n"
    injected += "【以上为长期记忆，请参考后再回答】\n"
    
    return injected

# ============ 自检 ============
def self_check() -> Dict[str, Any]:
    """系统自检"""
    results = {
        "status": "ok",
        "checks": [],
        "errors": []
    }
    
    # 检查目录
    for dir_name, dir_path in [
        ("logs", LOGS_DIR),
        ("summaries", SUMMARIES_DIR),
        ("facts", f"{CUSTOM_MEMORY_ROOT}/facts"),
        ("system", f"{CUSTOM_MEMORY_ROOT}/system"),
        ("errors", f"{CUSTOM_MEMORY_ROOT}/errors")
    ]:
        if os.path.exists(dir_path) and os.path.isdir(dir_path):
            results["checks"].append(f"✔ {dir_name}/ 目录正常")
        else:
            results["checks"].append(f"✘ {dir_name}/ 目录异常")
            results["errors"].append(f"{dir_name} 目录不存在")
    
    # 检查文件可读性
    for file_name, file_path in [
        ("facts.md", FACTS_FILE),
        ("system_prompt.md", SYSTEM_PROMPT_FILE)
    ]:
        if os.path.exists(file_path) and os.access(file_path, os.R_OK):
            results["checks"].append(f"✔ {file_name} 可读")
        else:
            results["checks"].append(f"✘ {file_name} 不可读")
    
    # 检查注入功能
    try:
        injected = inject_memory()
        if len(injected) > 100:
            results["checks"].append("✔ 记忆注入功能正常")
        else:
            results["checks"].append("⚠ 记忆注入内容过短")
    except Exception as e:
        results["checks"].append(f"✘ 记忆注入失败: {e}")
        results["errors"].append(str(e))
    
    if results["errors"]:
        results["status"] = "warning"
    
    return results

# ============ 生成每日总结 ============
def generate_daily_summary(date: Optional[str] = None) -> bool:
    """生成每日总结"""
    if date is None:
        date = datetime.now().strftime("%Y-%m-%d")
    
    log_file = f"{LOGS_DIR}/{date}.md"
    summary_file = f"{SUMMARIES_DIR}/summary-{date}.md"
    
    if not os.path.exists(log_file):
        return False
    
    try:
        with open(log_file, 'r', encoding='utf-8') as f:
            logs_content = f.read()
        
        # 简单的总结生成（实际使用时可调用 LLM）
        summary = f"# 每日总结 - {date}\n\n"
        summary += "## 活动记录\n"
        summary += logs_content
        summary += "\n## 关键要点\n"
        summary += "（请查看上方详细记录）\n"
        
        with open(summary_file, 'w', encoding='utf-8') as f:
            f.write(summary)
        
        return True
    except Exception as e:
        log_error("generate_summary", str(e), date)
        return False

if __name__ == "__main__":
    # 自检
    print("执行自检...")
    result = self_check()
    print(json.dumps(result, ensure_ascii=False, indent=2))
