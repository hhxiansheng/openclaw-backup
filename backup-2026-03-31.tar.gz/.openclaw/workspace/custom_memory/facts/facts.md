# 长期事实库

## 用户信息
- 用户名：运维小飞棍
- 地点：广州
- 时区：Asia/Shanghai
- 职业：究极打工仔

## 项目信息
- 2026-03-29：开始实现长期记忆系统（隔离版）

## 偏好设置
- 直接、高效、讨厌拖沓
- 喜欢干净利落的做事风格

## 系统信息
- OpenClaw 配置在 /home/hhxs/.openclaw/workspace
- 自定义记忆系统路径：custom_memory/

## 验证测试
- 这是验证测试添加的事实

## 服务信息
- 备份系统名称：openclaw备份管理系统
- systemd 服务名：openclaw-backup
- 服务路径：~/.config/systemd/user/openclaw-backup.service
