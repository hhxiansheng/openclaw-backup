#!/usr/bin/env python3
"""
长期记忆系统 - 核心管理器 (增强版)
隔离 OpenClaw 原生 memory，完全独立实现

功能：
1. 结构化每日总结（完成事项/未完成/长期目标/配置变更）
2. logs 过长时自动压缩成 summary
3. 启动时优先读取最近 3 天 summaries
4. 防止 memory 目录膨胀
"""

import os
import json
import shutil
import re
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, List, Dict, Any

# ============ 配置 ============
CUSTOM_MEMORY_ROOT = "/home/hhxs/.openclaw/workspace/custom_memory"
LOGS_DIR = f"{CUSTOM_MEMORY_ROOT}/logs"
SUMMARIES_DIR = f"{CUSTOM_MEMORY_ROOT}/summaries"
FACTS_FILE = f"{CUSTOM_MEMORY_ROOT}/facts/facts.md"
SYSTEM_PROMPT_FILE = f"{CUSTOM_MEMORY_ROOT}/system/system_prompt.md"
ERROR_LOG_FILE = f"{CUSTOM_MEMORY_ROOT}/errors/error.log"

# 膨胀控制配置
MAX_LOG_SIZE_KB = 50          # 单个 log 文件超过此大小则压缩
MAX_LOG_AGE_DAYS = 7           # logs 保留最近 N 天
MAX_SUMMARY_AGE_DAYS = 90      # summaries 保留最近 N 天

# ============ 初始化检查 ============
def init_memory_system():
    """初始化记忆系统，确保目录结构存在"""
    dirs = [LOGS_DIR, SUMMARIES_DIR, f"{CUSTOM_MEMORY_ROOT}/facts", 
            f"{CUSTOM_MEMORY_ROOT}/system", f"{CUSTOM_MEMORY_ROOT}/errors",
            f"{CUSTOM_MEMORY_ROOT}/snapshots", f"{CUSTOM_MEMORY_ROOT}/versions"]
    for d in dirs:
        os.makedirs(d, exist_ok=True)
    
    # 初始化 facts 文件
    if not os.path.exists(FACTS_FILE):
        with open(FACTS_FILE, 'w', encoding='utf-8') as f:
            f.write("# 长期事实库\n\n## 用户信息\n- 用户名：运维小飞棍\n- 地点：广州\n- 时区：Asia/Shanghai\n\n## 项目信息\n（待填充）\n\n## 偏好设置\n（待填充）\n\n")
    
    # 初始化 system prompt
    if not os.path.exists(SYSTEM_PROMPT_FILE):
        with open(SYSTEM_PROMPT_FILE, 'w', encoding='utf-8') as f:
            f.write("# 系统规则 - 长期记忆系统\n\n## 核心规则\n1. 每次对话开始必须读取 custom_memory/\n2. 必须告诉用户加载了哪些记忆\n3. 每次调用模型前必须执行 inject_memory\n4. 禁止使用 OpenClaw 原生 memory 目录\n\n## 目录结构\n```\ncustom_memory/\n├── logs/          # 每日详细记录\n├── summaries/     # 每日总结（结构化）\n├── facts/         # 长期信息\n├── system/        # 系统规则\n└── errors/        # 错误日志\n```\n\n## 记忆写入时机\n- 每轮对话结束\n- 任务完成时\n- 发现重要信息时\n\n## 记忆读取时机\n- 每次对话开始\n- 每次调用模型前\n")
    
    return True

# ============ 错误处理 ============
def log_error(operation: str, error: str, details: str = ""):
    """记录错误到 error.log"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(ERROR_LOG_FILE, 'a', encoding='utf-8') as f:
        f.write(f"[{timestamp}] 操作: {operation} | 错误: {error} | 详情: {details}\n")

# ============ 写入记忆 ============
def write_log(message: str, metadata: Optional[Dict] = None, tags: Optional[List[str]] = None):
    """
    写入每日日志
    
    Args:
        message: 日志内容
        metadata: 可选元数据（dict）
        tags: 可选标签列表，如 ["已完成", "重要", "配置变更"]
    """
    today = datetime.now().strftime("%Y-%m-%d")
    log_file = f"{LOGS_DIR}/{today}.md"
    
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    content = f"## {timestamp}\n\n"
    content += f"**消息**: {message}\n"
    if metadata:
        content += f"**元数据**: {json.dumps(metadata, ensure_ascii=False, indent=2)}\n"
    if tags:
        content += f"**标签**: {', '.join(tags)}\n"
    content += "\n---\n\n"
    
    for attempt in range(3):
        try:
            with open(log_file, 'a', encoding='utf-8') as f:
                f.write(content)
            
            # 检查是否需要压缩
            _check_and_compress_if_needed(log_file)
            return True
        except Exception as e:
            if attempt == 2:
                log_error("write_log", str(e), log_file)
            continue
    return False

def append_fact(category: str, fact: str, timestamp: bool = True):
    """追加长期事实"""
    for attempt in range(3):
        try:
            with open(FACTS_FILE, 'a', encoding='utf-8') as f:
                ts = datetime.now().strftime("%Y-%m-%d") if timestamp else ""
                prefix = f"[{ts}] " if ts else "- "
                f.write(f"\n## {category}\n{prefix}{fact}\n")
            return True
        except Exception as e:
            if attempt == 2:
                log_error("append_fact", str(e), FACTS_FILE)
            continue
    return False

# ============ 读取记忆 ============
def read_recent_summaries(days: int = 3) -> str:
    """读取最近N天的总结"""
    summaries = []
    today = datetime.now()
    
    for i in range(days):
        date = (today - timedelta(days=i)).strftime("%Y-%m-%d")
        summary_file = f"{SUMMARIES_DIR}/summary-{date}.md"
        if os.path.exists(summary_file):
            try:
                with open(summary_file, 'r', encoding='utf-8') as f:
                    summaries.append(f.read())
            except Exception as e:
                log_error("read_summary", str(e), summary_file)
    
    return "\n\n" + "="*50 + "\n\n".join(summaries) + "\n\n" if summaries else "\n\n（无历史总结）\n\n"

def read_facts() -> str:
    """读取长期事实"""
    if os.path.exists(FACTS_FILE):
        try:
            with open(FACTS_FILE, 'r', encoding='utf-8') as f:
                return f.read()
        except Exception as e:
            log_error("read_facts", str(e), FACTS_FILE)
    return "（无长期事实）"

def read_system_prompt() -> str:
    """读取系统提示"""
    if os.path.exists(SYSTEM_PROMPT_FILE):
        try:
            with open(SYSTEM_PROMPT_FILE, 'r', encoding='utf-8') as f:
                return f.read()
        except Exception as e:
            log_error("read_system_prompt", str(e), SYSTEM_PROMPT_FILE)
    return ""

def read_logs(days: int = 3) -> str:
    """读取最近N天的日志"""
    logs = []
    today = datetime.now()
    
    for i in range(days):
        date = (today - timedelta(days=i)).strftime("%Y-%m-%d")
        log_file = f"{LOGS_DIR}/{date}.md"
        if os.path.exists(log_file):
            try:
                with open(log_file, 'r', encoding='utf-8') as f:
                    logs.append(f"=== {date} ===\n{f.read()}")
            except Exception as e:
                log_error("read_logs", str(e), log_file)
    
    return "\n".join(logs) if logs else "（无日志）"

def get_summary_structure(date: str, log_content: str) -> str:
    """
    生成结构化总结
    
    格式：
    ## 日期
    ### ✅ 完成了什么
    ### ⏳ 未完成事项
    ### 🎯 当前长期目标
    ### 🔧 重要配置变更
    """
    summary = f"# 每日总结 - {date}\n\n"
    
    # 解析 log 内容，提取标签分类
    completed = []
    unfinished = []
    config_changes = []
    other = []
    
    entries = re.split(r'## \d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}', log_content)
    
    for entry in entries[1:]:  # 跳过第一个空部分
        if '标签' in entry:
            tags_match = re.search(r'\*\*标签\*\*: (.+)', entry)
            tags = tags_match.group(1).split(', ') if tags_match else []
            
            msg_match = re.search(r'\*\*消息\*\*: (.+)', entry)
            msg = msg_match.group(1) if msg_match else entry[:100]
            
            if '已完成' in tags:
                completed.append(msg)
            elif '未完成' in tags:
                unfinished.append(msg)
            elif '配置变更' in tags:
                config_changes.append(msg)
            else:
                other.append(msg)
    
    # 写入结构化内容
    summary += "## ✅ 完成了什么\n"
    if completed:
        for item in completed:
            summary += f"- {item}\n"
    else:
        summary += "- （无）\n"
    
    summary += "\n## ⏳ 未完成事项\n"
    if unfinished:
        for item in unfinished:
            summary += f"- {item}\n"
    else:
        summary += "- （无）\n"
    
    summary += "\n## 🎯 当前长期目标\n"
    summary += "- （见 facts.md 中的长期目标）\n"
    
    summary += "\n## 🔧 重要配置变更\n"
    if config_changes:
        for item in config_changes:
            summary += f"- {item}\n"
    else:
        summary += "- （无）\n"
    
    summary += "\n---\n\n## 📝 原始日志\n"
    summary += log_content
    
    return summary

# ============ 记忆注入 ============
def inject_memory() -> str:
    """
    核心功能：拼接所有记忆到统一上下文
    必须在调用模型前执行此函数
    """
    separator = "\n" + "="*50 + "\n"
    
    injected = f"{separator}【长期记忆系统 - 记忆注入】{separator}"
    injected += f"## 最近3天总结:{read_recent_summaries(3)}{separator}"
    injected += f"## 长期事实:\n{read_facts()}{separator}"
    injected += f"## 系统规则:\n{read_system_prompt()}{separator}"
    injected += "="*50 + "\n"
    injected += "【以上为长期记忆，请参考后再回答】\n"
    
    return injected

# ============ 自检 ============
def self_check() -> Dict[str, Any]:
    """系统自检"""
    results = {
        "status": "ok",
        "checks": [],
        "errors": [],
        "stats": {}
    }
    
    # 检查目录
    for dir_name, dir_path in [
        ("logs", LOGS_DIR),
        ("summaries", SUMMARIES_DIR),
        ("facts", f"{CUSTOM_MEMORY_ROOT}/facts"),
        ("system", f"{CUSTOM_MEMORY_ROOT}/system"),
        ("errors", f"{CUSTOM_MEMORY_ROOT}/errors")
    ]:
        if os.path.exists(dir_path) and os.path.isdir(dir_path):
            results["checks"].append(f"✔ {dir_name}/ 目录正常")
        else:
            results["checks"].append(f"✘ {dir_name}/ 目录异常")
            results["errors"].append(f"{dir_name} 目录不存在")
    
    # 统计文件数量和大小
    def get_dir_stats(path):
        total_size = 0
        file_count = 0
        for f in os.listdir(path) if os.path.exists(path) else []:
            fp = os.path.join(path, f)
            if os.path.isfile(fp):
                total_size += os.path.getsize(fp)
                file_count += 1
        return file_count, total_size
    
    logs_count, logs_size = get_dir_stats(LOGS_DIR)
    sum_count, sum_size = get_dir_stats(SUMMARIES_DIR)
    
    results["stats"] = {
        "logs文件数": logs_count,
        "logs总大小": f"{logs_size/1024:.1f} KB",
        "summaries文件数": sum_count,
        "summaries总大小": f"{sum_size/1024:.1f} KB"
    }
    
    # 检查注入功能
    try:
        injected = inject_memory()
        if len(injected) > 100:
            results["checks"].append("✔ 记忆注入功能正常")
        else:
            results["checks"].append("⚠ 记忆注入内容过短")
    except Exception as e:
        results["checks"].append(f"✘ 记忆注入失败: {e}")
        results["errors"].append(str(e))
    
    if results["errors"]:
        results["status"] = "warning"
    
    return results

# ============ 日志压缩 ============
def _check_and_compress_if_needed(log_file: str):
    """检查 log 文件大小，必要时压缩"""
    try:
        size_kb = os.path.getsize(log_file) / 1024
        if size_kb > MAX_LOG_SIZE_KB:
            date_match = re.search(r'(\d{4}-\d{2}-\d{2})', log_file)
            if date_match:
                date = date_match.group(1)
                with open(log_file, 'r', encoding='utf-8') as f:
                    content = f.read()
                summary = get_summary_structure(date, content)
                summary_file = f"{SUMMARIES_DIR}/summary-{date}.md"
                
                # 追加到 summary（如果已存在则合并）
                if os.path.exists(summary_file):
                    with open(summary_file, 'r', encoding='utf-8') as f:
                        existing = f.read()
                    # 在原始日志前插入新内容
                    summary = existing + "\n\n---\n\n# 补充记录\n\n" + summary
                
                with open(summary_file, 'w', encoding='utf-8') as f:
                    f.write(summary)
                
                # 清空 log 文件，保留标题
                with open(log_file, 'w', encoding='utf-8') as f:
                    f.write(f"# {date} 日志（已压缩至 summary）\n")
                
                log_error("auto_compress", f"已压缩 {log_file} ({size_kb:.1f}KB)", summary_file)
    except Exception as e:
        log_error("_check_and_compress", str(e), log_file)

def compress_log(date: str) -> bool:
    """手动压缩指定日期的日志"""
    log_file = f"{LOGS_DIR}/{date}.md"
    if not os.path.exists(log_file):
        return False
    
    try:
        with open(log_file, 'r', encoding='utf-8') as f:
            content = f.read()
        
        summary = get_summary_structure(date, content)
        summary_file = f"{SUMMARIES_DIR}/summary-{date}.md"
        
        if os.path.exists(summary_file):
            with open(summary_file, 'r', encoding='utf-8') as f:
                existing = f.read()
            summary = existing + "\n\n---\n\n# 补充记录\n\n" + summary
        
        with open(summary_file, 'w', encoding='utf-8') as f:
            f.write(summary)
        
        with open(log_file, 'w', encoding='utf-8') as f:
            f.write(f"# {date} 日志（已压缩）\n")
        
        return True
    except Exception as e:
        log_error("compress_log", str(e), date)
        return False

# ============ 清理过期文件 ============
def cleanup_old_files() -> Dict[str, int]:
    """
    清理过期的 logs 和 summaries
    返回清理统计
    """
    stats = {"logs_deleted": 0, "summaries_deleted": 0}
    today = datetime.now()
    
    # 清理 old logs
    if os.path.exists(LOGS_DIR):
        for f in os.listdir(LOGS_DIR):
            if re.match(r'\d{4}-\d{2}-\d{2}\.md', f):
                date_str = f.replace('.md', '')
                try:
                    file_date = datetime.strptime(date_str, '%Y-%m-%d')
                    age = (today - file_date).days
                    if age > MAX_LOG_AGE_DAYS:
                        os.remove(os.path.join(LOGS_DIR, f))
                        stats["logs_deleted"] += 1
                except ValueError:
                    pass
    
    # 清理 old summaries
    if os.path.exists(SUMMARIES_DIR):
        for f in os.listdir(SUMMARIES_DIR):
            if re.match(r'summary-\d{4}-\d{2}-\d{2}\.md', f):
                date_str = re.search(r'(\d{4}-\d{2}-\d{2})', f).group(1)
                try:
                    file_date = datetime.strftime(datetime.strptime(date_str, '%Y-%m-%d'), '%Y-%m-%d')
                    file_dt = datetime.strptime(date_str, '%Y-%m-%d')
                    age = (today - file_dt).days
                    if age > MAX_SUMMARY_AGE_DAYS:
                        os.remove(os.path.join(SUMMARIES_DIR, f))
                        stats["summaries_deleted"] += 1
                except ValueError:
                    pass
    
    return stats

# ============ 高优先级事件检测 ============
HIGH_PRIORITY_KEYWORDS = [
    "配置变更", "修改配置", "新增服务", "安装服务", "服务安装",
    "修改脚本", "新增脚本", "修改 cron", "新增 cron", "crontab",
    "端口", "修改端口", "新增端口", "部署", "重启服务",
    "systemd", "service", "nginx", "docker", "端口映射",
    "firewall", "iptables", "环境变量", "PATH", "配置文件"
]

def detect_high_priority_events(log_content: str) -> List[str]:
    """检测日志中的高优先级事件"""
    events = []
    for keyword in HIGH_PRIORITY_KEYWORDS:
        if keyword in log_content:
            events.append(keyword)
    return events

def extract_config_changes(log_content: str) -> List[str]:
    """提取配置变更详情"""
    changes = []
    # 匹配类似 "配置: xxx → yyy" 或 "从 xxx 改为 yyy" 的模式
    patterns = [
        r'配置变更[：:]\s*(.+)',
        r'修改[：:]\s*(.+)',
        r'端口[：:]\s*(\d+)\s*→\s*(\d+)',
        r'(\w+)\s*→\s*(.+)',
    ]
    for pattern in patterns:
        matches = re.findall(pattern, log_content)
        for match in matches:
            if isinstance(match, tuple):
                changes.append(f"{match[0]} → {match[1]}")
            else:
                changes.append(str(match))
    return changes

def write_high_priority_to_facts(date: str, log_content: str) -> bool:
    """
    检测高优先级事件并写入 facts.md
    """
    events = detect_high_priority_events(log_content)
    if not events:
        return False
    
    changes = extract_config_changes(log_content)
    
    fact_entries = []
    fact_entries.append(f"## {date} 高优先级事件")
    fact_entries.append(f"- 日期: {date}")
    fact_entries.append(f"- 事件类型: {', '.join(events)}")
    
    if changes:
        fact_entries.append(f"- 变更详情:")
        for change in changes[:5]:  # 最多5条
            fact_entries.append(f"  - {change}")
    
    fact_entries.append(f"- 原始日志: 见 logs/{date}.md")
    fact_entries.append("")  # 空行分隔
    
    try:
        # 追加到 facts.md 末尾
        with open(FACTS_FILE, 'a', encoding='utf-8') as f:
            f.write("\n" + "\n".join(fact_entries))
        
        # 追加到当日 summary（如果存在）
        summary_file = f"{SUMMARIES_DIR}/summary-{date}.md"
        if os.path.exists(summary_file):
            with open(summary_file, 'a', encoding='utf-8') as f:
                f.write("\n\n## 🚨 高优先级事件\n")
                for entry in fact_entries[1:]:  # 跳过标题
                    f.write(f"{entry}\n")
        
        return True
    except Exception as e:
        log_error("write_high_priority", str(e), date)
        return False

def is_log_meaningful(date: str) -> bool:
    """检查指定日期的日志是否有实质内容（不是只有标题）"""
    log_file = f"{LOGS_DIR}/{date}.md"
    if not os.path.exists(log_file):
        return False
    
    try:
        with open(log_file, 'r', encoding='utf-8') as f:
            content = f.read().strip()
        # 如果只有标题或内容太短，认为无意义
        lines = content.split('\n')
        meaningful_lines = [l for l in lines if l.strip() and not l.startswith('#')]
        return len(meaningful_lines) > 0
    except Exception:
        return False

# ============ 生成每日总结 ============
def generate_daily_summary(date: Optional[str] = None) -> bool:
    """
    生成每日总结（结构化版本）
    只有当日志有实质内容时才生成总结
    """
    if date is None:
        date = datetime.now().strftime("%Y-%m-%d")
    
    log_file = f"{LOGS_DIR}/{date}.md"
    summary_file = f"{SUMMARIES_DIR}/summary-{date}.md"
    
    # 检查日志是否有实质内容
    if not is_log_meaningful(date):
        return False
    
    try:
        with open(log_file, 'r', encoding='utf-8') as f:
            logs_content = f.read()
        
        # 如果 log 已被压缩（只剩标题），直接用现有 summary
        if len(logs_content.strip().split('\n')) <= 2:
            return True
        
        summary = get_summary_structure(date, logs_content)
        
        with open(summary_file, 'w', encoding='utf-8') as f:
            f.write(summary)
        
        # 清空原始 log
        with open(log_file, 'w', encoding='utf-8') as f:
            f.write(f"# {date} 日志（已生成总结）\n")
        
        return True
    except Exception as e:
        log_error("generate_summary", str(e), date)
        return False

def generate_all_summaries() -> int:
    """为所有有日志的日期生成总结"""
    count = 0
    if os.path.exists(LOGS_DIR):
        for f in os.listdir(LOGS_DIR):
            if re.match(r'\d{4}-\d{2}-\d{2}\.md', f):
                date = f.replace('.md', '')
                if generate_daily_summary(date):
                    count += 1
    return count

# ============ 主程序 ============
if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        # 自检
        print("执行自检...")
        result = self_check()
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        cmd = sys.argv[1]
        if cmd == "check":
            result = self_check()
            print(json.dumps(result, ensure_ascii=False, indent=2))
        elif cmd == "cleanup":
            stats = cleanup_old_files()
            print(f"清理完成: 删除了 {stats['logs_deleted']} 个 logs, {stats['summaries_deleted']} 个 summaries")
        elif cmd == "generate":
            date = sys.argv[2] if len(sys.argv) > 2 else None
            if generate_daily_summary(date):
                print(f"总结生成成功: {date or '今天'}")
            else:
                print(f"总结生成失败或无日志: {date or '今天'}")
        elif cmd == "compress":
            if len(sys.argv) > 2:
                if compress_log(sys.argv[2]):
                    print(f"压缩成功: {sys.argv[2]}")
                else:
                    print(f"压缩失败: {sys.argv[2]}")
            else:
                print("用法: compress <YYYY-MM-DD>")
        elif cmd == "generate-all":
            count = generate_all_summaries()
            print(f"批量生成完成: {count} 个总结")
        else:
            print(f"未知命令: {cmd}")
            print("可用命令: check, cleanup, generate [date], compress <date>, generate-all")
