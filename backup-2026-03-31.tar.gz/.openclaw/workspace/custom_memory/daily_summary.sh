#!/bin/bash
# 每日总结生成脚本 - 凌晨 4:00 执行
# 配合 crontab: 0 4 * * * /home/hhxs/.openclaw/workspace/custom_memory/daily_summary.sh

DATE=$(date +%Y-%m-%d)
LOG_FILE="/home/hhxs/.openclaw/workspace/custom_memory/logs/daily_summary.log"
LOG_DIR="/home/hhxs/.openclaw/workspace/custom_memory/logs"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}

log "===== 开始每日维护 ====="

# 1. 检查昨天是否有实质日志
YESTERDAY=$(date -d "yesterday" +%Y-%m-%d)
LOG_FILE_YESTERDAY="$LOG_DIR/${YESTERDAY}.md"

if [ -f "$LOG_FILE_YESTERDAY" ]; then
    # 检查是否有实质内容（不是只有标题）
    CONTENT_LINES=$(grep -v '^#' "$LOG_FILE_YESTERDAY" | grep -v '^$' | wc -l)
    
    if [ "$CONTENT_LINES" -gt 0 ]; then
        log "检测到昨天有实质日志，开始生成总结..."
        
        # 生成昨天的总结
        python3 /home/hhxs/.openclaw/workspace/custom_memory/memory_manager.py generate "$YESTERDAY" >> "$LOG_FILE" 2>&1
        
        # 检测高优先级事件并写入 facts
        python3 -c "
import sys
sys.path.insert(0, '/home/hhxs/.openclaw/workspace/custom_memory')
from memory_manager import read_logs, write_high_priority_to_facts

log_content = read_logs(1)  # 读取昨天
if '$YESTERDAY' in log_content and len(log_content) > 100:
    result = write_high_priority_to_facts('$YESTERDAY', log_content)
    if result:
        print('HIGH_PRIORITY: 已将高优先级事件写入 facts.md')
    else:
        print('HIGH_PRIORITY: 无高优先级事件')
" >> "$LOG_FILE" 2>&1
    else
        log "昨天无实质对话，跳过总结生成"
    fi
else
    log "昨天无日志文件，跳过总结生成"
fi

# 2. 清理过期文件
python3 /home/hhxs/.openclaw/workspace/custom_memory/memory_manager.py cleanup >> "$LOG_FILE" 2>&1

log "===== 每日维护完成 ====="

# 保留日志只留最近 30 条
if [ -f "$LOG_FILE" ]; then
    tail -n 30 "$LOG_FILE" > "${LOG_FILE}.tmp" && mv "${LOG_FILE}.tmp" "$LOG_FILE"
fi
